Práctica 6, primera parte: Fórmulas proposicionales
Integrantes: 2
Nombre                              No. de cuenta   Correo
               -                                   - 

