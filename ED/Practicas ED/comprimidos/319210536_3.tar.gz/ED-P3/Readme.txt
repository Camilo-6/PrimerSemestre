Práctica 3: Recursión
Integrantes: 1
Nombre                              No. de cuenta   Correo
García Ponce José Camilo       -      319210536   -  jcamilo@ciencias.unam.mx

Comentarios(opcionales):
en la 2 puse que 1 no es primo, no se si esto esta bien
suma_triangulo no es nada eficiente creo, porque se tarda mucho su prueba unu, se tarda casi 5 segundos, no se si este bien del todo