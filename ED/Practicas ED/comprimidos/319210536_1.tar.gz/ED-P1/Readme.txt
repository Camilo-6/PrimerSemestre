Práctica 1: Introducción a Python
Integrantes: 1
Nombre                              No. de cuenta   Correo
García Ponce José Camilo       -      319210536   -  jcamilo@ciencias.unam.mx

Comentarios(opcionales):

en la primer funcion intente poner numero muy grandes y no se si mi computuadora no lo soporto o la funcion tarda mucho
por ejemplo puse (236994568,375787587) y su MCD es 1, pero pasaron como 2 minutos y seguia "ejecutando"

en la tercera no se como no mostrar tantos decimales

en la quinta no se como usar lambda unu

en el septimo intente hacer algo diferente al que vimos en clase

los mas dificiles fueron el 4, 6 y 10 y busque ayuda en internet para hacer estos porque son algo raros

para la de triangulos y pascal creo que hice muchos pasos para que saliera